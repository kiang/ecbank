<?php
/**
 * @package		HikaShop for Joomla!
 * @version		1.5.8
 * @author		hikashop.com
 * @copyright	(C) 2010-2012 HIKARI SOFTWARE. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
?>

<div class="hikashop_gwbarcode_end" id="hikashop_gwbarcode_end">
	<br/>
	<form id="hikashop_gwbarcode_form" name="hikashop_gwbarcode_form" action="<?php echo $method->payment_params->url;?>" method="post">
		<?php  
                    echo 'Thank you for your order!<br>';                    
                    echo $vars["html"];
                ////不用在submit出去其他網址付錢了，只需要顯示列印barcode繳費單的網址即可
		?>
	</form>
</div>