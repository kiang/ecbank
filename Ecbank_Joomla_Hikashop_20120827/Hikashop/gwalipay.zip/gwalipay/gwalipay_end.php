<?php
/**
 * @package		HikaShop for Joomla!
 * @version		1.5.8
 * @author		hikashop.com
 * @copyright	(C) 2010-2012 HIKARI SOFTWARE. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
?>
<div class="hikashop_gwbarcode_end" id="hikashop_gwbarcode_end">
<br/>
<?php  //先上傳商品資料
$config = new JConfig();
$conn = mysql_connect($config->host,$config->user,$config->password);
mysql_select_db($config->db,$conn);
$sql = "SELECT product_id,order_product_name,order_product_price,order_product_quantity FROM ".$config->dbprefix."hikashop_order_product WHERE order_id=".$vars["transaction_id"];
$result = mysql_query($sql);
$arr = '';
while($rows=mysql_fetch_row($result)){
    $arr[]=$rows;
}
for ($i=0;$i<count($arr);$i++){
  $enc_key = $vars['secret_word'];
  $type="upload_goods";
  $mer_id=$vars['mer_id'];
  $goods_id = $arr[$i][0];// 商品編號
  $goods_title = $arr[$i][1];// 商品名稱
  $goods_price = round($arr[$i][2]);// 商品單價
  $sql = "SELECT product_url FROM ".$config->dbprefix."hikashop_product WHERE product_id=".$arr[$i][0];
  $url = mysql_fetch_row(mysql_query($sql));
  $goods_href = $url[0];// 商品網址
  $ecbank_gateway = 'https://ecbank.com.tw/web_service/alipay_goods_upload.php';// ECBank 商品上架網址。
  $post_str='enc_key='.$enc_key.  // 串接驗證參數
  	  '&mer_id='.$mer_id.
	  '&type='.$type.
	  '&goods_id='.$goods_id.
	  '&goods_title='.$goods_title.
	  '&goods_price='.$goods_price.
	  '&goods_href='.$goods_href;
  $ch = curl_init();  // 使用curl取得驗證結果
  curl_setopt($ch, CURLOPT_URL,$ecbank_gateway);
  curl_setopt($ch, CURLOPT_VERBOSE, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
  curl_setopt($ch,CURLOPT_POSTFIELDS,$post_str);
  $strAuth = curl_exec($ch);
  if (curl_errno($ch)){
    $strAuth = false;
  }
}
curl_close($ch);
/*if($strAuth == 'state=NEW_SUCCESS'){
	echo '新增上架商品成功';
}else if($strAuth == 'state=MODIFY_SUCCESS'){
	echo '修改上架商品成功';
}else{
    echo '錯誤：'.$strAuth;
}*/ 
//--------------------------------------------------------------------------------------------------------

    echo 'Thank you for your order!<br>';
    $html = '<table border = "2">' . "\n";
    $html .= $this->getHtmlRow('付款方式', $vars['payment_type'].'<br>'.$method->payment_description);
    $str = stristr($_SERVER['PHP_SELF'],"index.php"); //擷取response位址
    $old_arry = explode ("/",$str);
    $full_arry = explode ("/",$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']);
    $cat_url = "";
        foreach($full_arry as $v){
            if($v == $old_arry[0]){
                break;	
            }
        $cat_url .= $v."/";
        }
    $ok_url = "http://".$cat_url."plugins/hikashoppayment/gwalipay/response.php";
    $html .= $this->getHtmlRow('訂單編號', $vars["order_num"]);
    $html .= $this->getHtmlRow('交易金額', round($vars['amount']));
    $html .= '</table>' . "\n";
    echo $html;
?>
</div>
<form method="post" action="https://ecbank.com.tw/gateway.php">
	<input type="hidden" name="mer_id" value="<?php echo $vars["mer_id"]?>" />
	<input type="hidden" name="payment_type" value="alipay" />
	<input type="hidden" name="od_sob" value="<?php echo $vars["order_num"]?>" />
	<input type="hidden" name="amt" value="<?php echo round($vars["amount"])?>" />
	<input type="hidden" name="ok_url" value="<?php echo $vars["ok_url"]?>" />
	<input type="hidden" name="return_url" value="<?php echo $vars["ok_url"]?>" />
        <?php 
        for ($i=0;$i<count($arr);$i++){
      	echo '<input type="hidden" name="goods_name[]" value= '.$arr[$i][0].' />';
        echo '<input type="hidden" name="goods_amount[]" value='.$arr[$i][3].' />'; //數量
        }
        if ($method->payment_params->i_invoice == 'yes'){  //判斷是否開立電子發票
            echo '<input type="hidden" name="inv_active" value=1 />';
            echo '<input type="hidden" name="inv_mer_id" value='.$method->payment_params->imer_id.' />';
            echo '<input type="hidden" name="inv_amt" value='.round($vars['amount']).' />';
            echo '<input type="hidden" name="inv_semail" value='.$vars['pay_from_email'].' />';
            echo '<input type="hidden" name="inv_delay" value='.$method->payment_params->inv_delay.' />';
            for($i=0;$i<count($order->cart->products);$i++){
                echo '<input type="hidden" name="prd_name[]" value='.$order->cart->products[$i]->order_product_name.' />';
                echo '<input type="hidden" name="prd_qry[]" value='.$order->cart->products[$i]->order_product_quantity.' />';
                echo '<input type="hidden" name="prd_price[]" value='.$order->cart->products[$i]->order_product_price.' />';
            }
            echo '<input type="hidden" name="prd_name[]" value="運費" />';//運費
            echo '<input type="hidden" name="prd_qry[]" value=1 />';
            echo '<input type="hidden" name="prd_price[]" value='.round($order->order_shipping_price).' />';
        }    
        ?>
        <input type="submit" name="sub" value="pay now" />
</form>