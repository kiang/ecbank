<?php
/**
 * @package		HikaShop for Joomla!
 * @version		1.5.8
 * @author		hikashop.com
 * @copyright	(C) 2010-2012 HIKARI SOFTWARE. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
?>
	<td class="key">
		<label for="data[payment][payment_params][mer_id]">
			<?php echo JText::_( '商店代號' ); ?>
		</label>
	</td>
	<td>
		<input type="text" name="data[payment][payment_params][mer_id]" value="<?php echo @$this->element->payment_params->mer_id; ?>" />
	</td>
</tr>
<tr>
	<td class="key">
		<label for="data[payment][payment_params][secret_word]">
			<?php echo JText::_( '商家檢查碼' ); ?>
		</label>
	</td>
	<td>
		<input type="text" name="data[payment][payment_params][secret_word]" value="<?php echo @$this->element->payment_params->secret_word; ?>" />
	</td>
</tr>
<tr>
	<td class="key">
		<label for="data[payment][payment_params][rate]">
			<?php echo JText::_( '利率' ); ?>
		</label>
	</td>
	<td>
		<input type="text" name="data[payment][payment_params][rate]" value="<?php echo @$this->element->payment_params->rate; ?>" />
	</td>
</tr>
<tr>
	<td class="key">
		<label for="data[payment][payment_params][i_invoice]">
			<?php echo JText::_( '是否使用電子發票' ); ?>
		</label>
	</td>
	<td>
		<?php
		$values = array();
		$values[] = JHTML::_('select.option', 'no', JText::_('否'));
                $values[] = JHTML::_('select.option', 'yes', JText::_('是'));
		echo JHTML::_('select.genericlist', $values, "data[payment][payment_params][i_invoice]", 'class="inputbox" size="1"', 'value', 'text', @$this->element->payment_params->i_invoice ); ?>
	</td>
</tr>
<tr>
	<td class="key">
		<label for="data[payment][payment_params][imer_id]">
			<?php echo JText::_( '電子發票商店代號' ); ?>
		</label>
	</td>
	<td>
		<input type="text" name="data[payment][payment_params][imer_id]" value="<?php echo @$this->element->payment_params->imer_id; ?>" />
	</td>
</tr>
<tr>
	<td class="key">
		<label for="data[payment][payment_params][inv_delay]">
			<?php echo JText::_( '電子發票延遲開立天數' ); ?>
		</label>
	</td>
	<td>
		<input type="text" name="data[payment][payment_params][inv_delay]" value="<?php echo @$this->element->payment_params->inv_delay; ?>" />
	</td>
</tr>