<?php
/**
 * @package		HikaShop for Joomla!
 * @version		1.5.8
 * @author		hikashop.com
 * @copyright	(C) 2010-2012 HIKARI SOFTWARE. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
?>

<div class="hikashop_gwbarcode_end" id="hikashop_gwbarcode_end">
	<br/>
	<form id="hikashop_gwbarcode_form" name="hikashop_gwbarcode_form" action="<?php echo $method->payment_params->url;?>" method="post">
		<?php  
                    //echo $vars["res_str"];
                    echo 'Thank you for your order!<br>';
                    $html = '<table border = "2">' . "\n";
                    $html .= $this->getHtmlRow('付款方式', $vars['payment_type'].'<br>'.$method->payment_description);
                    $html .= $this->getHtmlRow('訂單編號', $vars["order_num"]);
                    $html .= $this->getHtmlRow('交易金額', round($vars['amount']));
                    $html .= '</table>' . "\n";
                    echo $html;
		?>
	</form>
</div>
<form action="https://ecbank.com.tw/gateway.php" method="post">
	<input type="hidden" name="mer_id" value="<?php echo $vars['mer_id']?>" />
	<input type="hidden" name="payment_type" value="paypal" />
	<input type="hidden" name="od_sob" value="<?php echo $vars['order_num']?>" />
	<input type="hidden" name="amt" value="<?php echo round($vars['amount'])?>" />
	<input type="hidden" name="return_url" value="<?php echo $vars['ok_url']?>" />
	<input type='hidden' name='item_name' value='<?php echo $_SERVER['HTTP_HOST']?>'>
	<input type='hidden' name='cur_type' value='TWD'>
        <input type="submit" name="submit" value="pay now" />
</form>
