<?php
/**
 * @package		HikaShop for Joomla!
 * @version		1.5.8
 * @author		hikashop.com
 * @copyright	(C) 2010-2012 HIKARI SOFTWARE. All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
?>

<div class="hikashop_gwbarcode_end" id="hikashop_gwbarcode_end">
	<br/>
	<form id="hikashop_gwbarcode_form" name="hikashop_gwunionpay_form">
		<?php  
                    echo 'Thank you for your order!<br>';
                    $html = '<table border = "2">' . "\n";
                    $html .= $this->getHtmlRow('付款方式', $vars['payment_type'].'<br>'.$method->payment_description);
                    $str = stristr($_SERVER['PHP_SELF'],"index.php"); //擷取response位址
                    $old_arry = explode ("/",$str);
                    $full_arry = explode ("/",$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']);
                    $cat_url = "";
                    foreach($full_arry as $v){
                        if($v == $old_arry[0]){
                            break;	
                        }
                        $cat_url .= $v."/";
                    }
                    $ok_url = "http://".$cat_url."plugins/hikashoppayment/gwunionpay/response.php";
                    $html .= $this->getHtmlRow('訂單編號', $vars["order_num"]);
                    $html .= $this->getHtmlRow('交易金額', round($vars['amount']));
                    $html .= $this->getHtmlRow('利率', ($vars['rate']*100).'%');
                    $html .= '</table>' . "\n";
                    echo $html;
                    $config = new JConfig();
                    $conn = mysql_connect($config->host,$config->user,$config->password);
                    mysql_select_db($config->db,$conn);
                    $update = "update ".$config->dbprefix."hikashop_order set order_full_price = ".$vars['amount']." where order_id = ".$vars["order_id"];
                    mysql_query($update);                    
		?>
	</form>
</div>
<form action="https://ecpay.com.tw/form_Sc_to5.php" method="post">
	<input type="hidden" name="client" value="<?php echo $vars["mer_id"]?>" />
	<input type="hidden" name="act" value="auth" />
	<input type="hidden" name="od_sob" value="<?php echo $vars["order_num"]?>" />
	<input type="hidden" name="amount" value="<?php echo round($vars["amount"])?>" />
	<input type="hidden" name="roturl" value="<?php echo $vars["ok_url"]?>" />
	<input type="hidden" name="bk_posturl" value="<?php echo $vars["ok_url"]?>" />
      	<input type="hidden" name="mallurl" value="<?php echo $vars["ok_url"]?>" />
        <input type="hidden" name="CUPus" value="1" />
                <?php
            if ($method->payment_params->i_invoice == 'yes'){  //判斷是否開立電子發票
                echo '<input type="hidden" name="inv_active" value=1 />';
                echo '<input type="hidden" name="inv_mer_id" value='.$method->payment_params->imer_id.' />';
                echo '<input type="hidden" name="inv_amt" value='.$vars['amount'].' />';
                echo '<input type="hidden" name="inv_semail" value='.$vars['pay_from_email'].' />';
                echo '<input type="hidden" name="inv_delay" value='.$method->payment_params->inv_delay.' />';
                for($i=0;$i<count($order->cart->products);$i++){
                    echo '<input type="hidden" name="prd_name[]" value='.$order->cart->products[$i]->order_product_name.' />';
                    echo '<input type="hidden" name="prd_qry[]" value='.$order->cart->products[$i]->order_product_quantity.' />';
                    echo '<input type="hidden" name="prd_price[]" value='.$order->cart->products[$i]->order_product_price.' />';
                }
                    echo '<input type="hidden" name="prd_name[]" value="運費" />';//運費
                    echo '<input type="hidden" name="prd_qry[]" value=1 />';
                    echo '<input type="hidden" name="prd_price[]" value='.round($order->order_shipping_price).' />';
            }    
         ?>
        <input type="submit" name="sub" value="pay now" />
</form>