<?php
define('_JEXEC', 1);
define('DS', DIRECTORY_SEPARATOR);
define('JPATH_ROOT','..'.DS.'..'.DS.'..');
require(JPATH_ROOT. DS .'configuration.php');
$config = new JConfig();
$conn = mysql_connect($config->host,$config->user,$config->password);
$od_sob=trim($_REQUEST['od_sob']);
if(strlen($od_sob)>3){
    $od_id = substr($od_sob,1,1).substr($od_sob,3);
}
else{
    $od_id = substr($od_sob,1);
}
mysql_select_db($config->db,$conn);
$checkcode = "";
$sql = "SELECT payment_params FROM ".$config->dbprefix."hikashop_payment WHERE payment_name='gwcvs'";
$checkcodes = mysql_fetch_row(mysql_query($sql)); //讀出後台參數
$checkcode = strstr($checkcodes[0],"{"); //去掉大括號前端字串
$show = split(";",$checkcode); //根據分號切開參數 (第一維度)
for ($i = 0 ; $i <= count($show)-1; $i++){
    $show[$i] = split(":",$show[$i]);  // 根據冒號切開參數 (第二維度)
}
$param = '';
for ($i=0 ; $i<count($show) ; $i=$i+2){
    $param[str_replace('"','',$show[$i][2])]=str_replace('"','',$show[$i+1][2]);   //根據參數的屬性與其屬性值存入一為陣列作對應,且去掉 " 符號
   // echo '$show[$i][2]='.$show[$i][2].'<br>';
    //echo '$show[$i+1][2]='.$show[$i+1][2].'<br>';
   // echo '$param['.$show[$i][2].']='.$show[$i+1][2].'<br>';
    //echo $param[str_replace('"','',$show[$i][2])].'<br>'.'<br>';
}
$serial = trim($_REQUEST['proc_date'].$_REQUEST['proc_time'].$_REQUEST['tsr']);
$tac = trim($_REQUEST['tac']);
$ecbank_gateway = 'https://ecbank.com.tw/web_service/get_outmac_valid.php';
$post_parm	=	'key='.$param[secret_word].'&serial='.$serial.'&tac='.$tac;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$ecbank_gateway);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch,CURLOPT_POSTFIELDS,$post_parm);
$strAuth = curl_exec($ch);
if (curl_errno($ch)){
	$strAuth = false;
}
$sql = "SELECT order_full_price FROM ".$config->dbprefix."hikashop_order WHERE order_id=".$od_id;
$amt = mysql_fetch_row(mysql_query($sql));
if($strAuth == 'valid=1') {	
	if($_REQUEST['succ']=='1' && round($amt[0]) == $_REQUEST['amt']) {
		echo 'OK';
                $update = "update ".$config->dbprefix."hikashop_order set order_status = 'confirmed' where order_id =".$od_id;
                mysql_query($update);        
                //echo "<script>alert('付款成功');document.location.href='http://".$_SERVER['HTTP_HOST'].'/hikashop/index.php/hk-customer-orders'."';</script>";
                }else {
		echo "Failure";
	}   
}else{
	echo "Illegal";		
}
?>
