<?php
define('_JEXEC', 1);
define('DS', DIRECTORY_SEPARATOR);
define('JPATH_ROOT','..'.DS.'..'.DS.'..');
require(JPATH_ROOT. DS .'configuration.php');
$config = new JConfig();
$conn = mysql_connect($config->host,$config->user,$config->password);
//$od_id = substr(trim($_REQUEST['od_sob']),1,1).substr($_REQUEST['od_sob'],3);
$od_sob=trim($_REQUEST['od_sob']);
if(strlen($od_sob)>3){
    $od_id = substr($od_sob,1,1).substr($od_sob,3);
}
else{
    $od_id = substr($od_sob,1);
}
mysql_select_db($config->db,$conn);
$checkcodes = "";
$sql = "SELECT payment_params FROM ".$config->dbprefix."hikashop_payment WHERE payment_name='gwecpay'";
$result1 = mysql_fetch_row(mysql_query($sql)); //讀出後台參數
$checkcodes = strstr($result1[0],"{"); //去掉大括號前端字串
$checkcode = split(";",$checkcodes); //根據分號切開參數 (第一維度)
for ($i = 0 ; $i <= count($checkcode)-1; $i++){
    $checkcode[$i] = split(":",$checkcode[$i]);  // 根據冒號切開參數 (第二維度)
}
$param = '';
for ($i=0 ; $i<count($checkcode) ; $i=$i+2){
    $param[str_replace('"','',$checkcode[$i][2])]=str_replace('"','',$checkcode[$i+1][2]);   //根據參數的屬性與其屬性值存入一為陣列作對應,且去掉 " 符號
    //echo '$checkcode[$i][2]='.$checkcode[$i][2].'<br>';
    //echo '$checkcode[$i+1][2]='.$checkcode[$i+1][2].'<br>';
    //echo '$param['.$checkcode[$i][2].']='.$checkcode[$i+1][2].'<br>';
    //echo $param[str_replace('"','',$checkcode[$i][2])].'<br>'.'<br>';
}
function gwSpcheck($s,$U) {
	$a = substr($U,0,1).substr($U,2,1).substr($U,4,1);
	$b = substr($U,1,1).substr($U,3,1).substr($U,5,1);
	$c = ( $s % $U ) + $s + $a + $b;
        //echo '( $s % $U )='.( $s % $U ).'<br>';
        //echo '$a='.$a.'  $b='.$b.'  $c='.$c.'<br>';
	return $c;
}
$dir_url='';
$p=explode('/',$_SERVER["PHP_SELF"]);
$dir_url=$_SERVER['HTTP_HOST'].'/'.$p[1];
$TOkSi = $_REQUEST['process_time'] + $_REQUEST['gwsr'] + $_REQUEST['amount'];
/*echo '$_REQUEST[process_time]='.$_REQUEST['process_time'].'<br>';
echo '$_REQUEST[gwsr]='.$_REQUEST['gwsr'].'<br>';
echo '$_REQUEST[amount]'.$_REQUEST['amount'].'<br>';
echo '$TOkSi ='.$TOkSi.'<br>';
echo '$param[secret_word]='.$param['secret_word'].'<br>';*/
$my_spcheck = gwSpcheck($param['secret_word'],$TOkSi);
$sql = "SELECT order_full_price FROM ".$config->dbprefix."hikashop_order WHERE order_id=".$od_id;
$amt = mysql_fetch_row(mysql_query($sql));
/*echo '$my_spcheck='.$my_spcheck.'<br>';
echo '$REQUEST[spcheck]='.$_REQUEST['spcheck'].'<br>';
echo '$_REQUEST[succ]='.$_REQUEST['succ'].'<br>';
echo '$_REQUEST[amount]='.$_REQUEST['amount'].'<br>';
echo '$od_id='.$od_id.'<br>';
echo '$amt[0]='.round($amt[0]);
pause();*/
if(($my_spcheck == $_REQUEST['spcheck'] && $_REQUEST['succ']=='1') && round($amt[0]) == $_REQUEST['amount']) {
        $update = "update ".$config->dbprefix."hikashop_order set order_status = 'confirmed' where order_id =".$od_id;
	mysql_query($update);
        echo 'OK<br>';
        if ($_REQUEST['inv_error']!=0){
            echo $_REQUEST['inv_error'];
        }
        echo "<script>alert('付款成功');document.location.href='http://".$dir_url.'/index.php/order'."';</script>";
}else {
	echo 'NO<br>';
        if ($_REQUEST['inv_error']!=0){
            echo $_REQUEST['inv_error'];
        }
        echo "<script>alert('付款失敗');document.location.href='http://".$dir_url.'/index.php/order'."';</script>";
}   
?>
