﻿<?php
define('_JEXEC', 1);
define('DS', DIRECTORY_SEPARATOR);
define('JPATH_ROOT','..'.DS.'..'.DS.'..');
require(JPATH_ROOT. DS .'configuration.php');
$config = new JConfig();
$conn = mysql_connect($config->host,$config->user,$config->password);
mysql_select_db($config->db,$conn);
$virtuemart_paymentmethod_id = $_GET['vpid'];
$order_id = $_GET['order_id'];
$od_sob = $_GET['od_sob'];
$amt = $_GET['amt'];
$inv = $_GET['inv'];
$return_url = "http://".$_SERVER['HTTP_HOST'].str_replace(basename(__FILE__),"response.php",$_SERVER['PHP_SELF'])
."?vpid=".$virtuemart_paymentmethod_id."&order_id=".$order_id;
$mer_id = "";
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_payment_plg_unionpay WHERE virtuemart_order_id=".$order_id." and order_number = '".$od_sob."' and virtuemart_paymentmethod_id=".$virtuemart_paymentmethod_id;
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){
	$mer_id = $row['mer_id'];
        $imer_id = $row['imer_id'];
        $delay = $row['delay'];
}
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_order_items where virtuemart_order_id=".$order_id;
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){
	$rows[] = $row;
}
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_order_userinfos where virtuemart_order_id=".$order_id;
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){
	$email = $row['email'];
}
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_orders where virtuemart_order_id=".$order_id;
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){
	$subtotal = $row['order_subtotal'];
        $order_shipment = $row['order_shipment'];
}
?>
<form action="https://ecpay.com.tw/form_Sc_to5.php" method="post">
	<input type="hidden" name="client" value="<?php echo $mer_id?>" />
	<input type="hidden" name="act" value="auth" />
	<input type="hidden" name="od_sob" value="<?php echo $od_sob?>" />
	<input type="hidden" name="amount" value="<?php echo $amt?>" />
	<input type="hidden" name="roturl" value="<?php echo $return_url?>" />
	<input type="hidden" name="bk_posturl" value="<?php echo $return_url?>" />
	<input type="hidden" name="mallurl" value="<?php echo $return_url?>" />
        <input type="hidden" name="CUPus" value="1" />        
        <?php
            if ($inv == 'yes'){ //電子發票
                echo '<input type="hidden" name="inv_active" value="1" />';
                echo '<input type="hidden" name="inv_mer_id" value='.$imer_id.' />';
                echo '<input type="hidden" name="inv_semail" value='.$email.' />';
                echo '<input type="hidden" name="inv_amt" value='.$amt.' />';
                echo '<input type="hidden" name="inv_delay" value='.$delay.' />';
                foreach($rows as $p){
                    echo '<input type="hidden" name="prd_name[]" value='.$p['order_item_name'].' />';
                    echo '<input type="hidden" name="prd_qry[]" value='.$p['product_quantity'].' />';
                    echo '<input type="hidden" name="prd_price[]" value='.$p['product_final_price'].' />';
                }
                echo '<input type="hidden" name="prd_name[]" value="手續費" />';
                echo '<input type="hidden" name="prd_qry[]" value=1 />';
                echo '<input type="hidden" name="prd_price[]" value='.$order_shipment.' />';
                echo '<input type="hidden" name="prd_name[]" value="利息" />';
                echo '<input type="hidden" name="prd_qry[]" value=1 />';
                echo '<input type="hidden" name="prd_price[]" value='.(round($amt)-round($subtotal)-round($order_shipment)).' />';
            }
        ?>           
</form>
<script type="text/javascript" language="javascript">
function do_submit() { document.forms[0].submit(); }
	do_submit();
</script>