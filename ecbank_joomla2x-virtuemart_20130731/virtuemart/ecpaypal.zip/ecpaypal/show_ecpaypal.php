﻿<?php
define('_JEXEC', 1);
define('DS', DIRECTORY_SEPARATOR);
define('JPATH_ROOT','..'.DS.'..'.DS.'..');
require(JPATH_ROOT. DS .'configuration.php');
$config = new JConfig();
$conn = mysql_connect($config->host,$config->user,$config->password);
mysql_select_db($config->db,$conn);
$virtuemart_paymentmethod_id = $_GET['vpid'];
$order_id = $_GET['order_id'];
$od_sob = $_GET['od_sob'];
$amt = $_GET['amt'];
$return_url = "http://".$_SERVER['HTTP_HOST'].DS.str_replace(basename(__FILE__),"response.php",$_SERVER['PHP_SELF'])
."?vpid=".$virtuemart_paymentmethod_id."&order_id=".$order_id;
$mer_id = "";
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_payment_plg_ecpaypal WHERE virtuemart_order_id=".$order_id." and order_number = '".$od_sob."' and virtuemart_paymentmethod_id=".$virtuemart_paymentmethod_id;
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){
	$mer_id = $row['mer_id'];
}
?>
<form action="https://ecbank.com.tw/gateway.php" method="post">
	<input type="hidden" name="mer_id" value="<?php echo $mer_id?>" />
	<input type="hidden" name="payment_type" value="paypal" />
	<input type="hidden" name="od_sob" value="<?php echo $od_sob?>" />
	<input type="hidden" name="amt" value="<?php echo $amt?>" />
	<input type="hidden" name="return_url" value="<?php echo $return_url?>" />
	<input type='hidden' name='item_name' value='<?php echo $_SERVER['HTTP_HOST']?>'>
	<input type='hidden' name='cur_type' value='TWD'>
	<input type='hidden' name='cancel_url' value='<?php echo "http://".$_SERVER['HTTP_HOST']?>'>
</form>
<script type="text/javascript" language="javascript">
function do_submit() { document.forms[0].submit(); }
	do_submit();
</script>