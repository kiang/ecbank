﻿<?php
define('_JEXEC', 1);
define('DS', DIRECTORY_SEPARATOR);
define('JPATH_ROOT','..'.DS.'..'.DS.'..');
require(JPATH_ROOT. DS .'configuration.php');
$config = new JConfig();
$conn = mysql_connect($config->host,$config->user,$config->password);
mysql_select_db($config->db,$conn);
$order_id = $_GET['order_id'];
$virtuemart_paymentmethod_id = $_GET['vpid'];
$od_sob = $_REQUEST['od_sob'];
$checkcode = "";
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_payment_plg_webatm WHERE virtuemart_order_id=".$order_id." and order_number = '".$od_sob."' and virtuemart_paymentmethod_id=".$virtuemart_paymentmethod_id;
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){
	$checkcode = $row['keys'];
}
$serial = trim($_REQUEST['proc_date'].$_REQUEST['proc_time'].$_REQUEST['tsr']);
$tac = trim($_REQUEST['tac']);
$ecbank_gateway = 'https://ecbank.com.tw/web_service/get_outmac_valid.php';
$post_parm	=	'key='.$checkcode.'&serial='.$serial.'&tac='.$tac;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$ecbank_gateway);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch,CURLOPT_POSTFIELDS,$post_parm);
$strAuth = curl_exec($ch);
if (curl_errno($ch)){
	$strAuth = false;
}
$dir_url='';
$p=explode('/',$_SERVER["PHP_SELF"]);
$dir_url=$_SERVER['HTTP_HOST'].'/'.$p[1];
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_orders where virtuemart_order_id=".$order_id; //增加amt判斷
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){  
	$amt = $row['order_total'];
}
if($strAuth == 'valid=1') {	
	if($_REQUEST['succ']=='1' && $amt == $_REQUEST['amt']) {
		echo "OK";
		$update = "update ".$config->dbprefix."virtuemart_orders set order_status = 'C' where virtuemart_order_id = ".$order_id;
		mysql_query($update);
		$update = "update ".$config->dbprefix."virtuemart_order_items set order_status = 'C' where virtuemart_order_id = ".$order_id;
		mysql_query($update);
                echo "<script>alert('付款成功');document.location.href='http://".$_SERVER['HTTP_HOST']."';</script>";         
	}else {
		echo "<script>alert('付款失敗');document.location.href='http://".$_SERVER['HTTP_HOST']."';</script>";
	}   
}else{
	echo "<script>alert('不合法交易');document.location.href='http://".$_SERVER['HTTP_HOST']."';</script>";
}
?>