﻿<?php
define('_JEXEC', 1);
define('DS', DIRECTORY_SEPARATOR);
define('JPATH_ROOT','..'.DS.'..'.DS.'..');
require(JPATH_ROOT. DS .'configuration.php');
$config = new JConfig();
$conn = mysql_connect($config->host,$config->user,$config->password);
mysql_select_db($config->db,$conn);
$order_id = $_GET['order_id'];
$virtuemart_paymentmethod_id = $_GET['vpid'];
$od_sob = $_REQUEST['od_sob'];
$checkcode = "";
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_payment_plg_allpay WHERE virtuemart_order_id=".$order_id." and order_number = '".$od_sob."' and virtuemart_paymentmethod_id=".$virtuemart_paymentmethod_id;
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){
	$checkcode = $row['keys'];
}
function gwSpcheck($s,$U) {
	$a = substr($U,0,1).substr($U,2,1).substr($U,4,1);
	$b = substr($U,1,1).substr($U,3,1).substr($U,5,1);
	$c = ( $s % $U ) + $s + $a + $b;
	return $c;
}
$dir_url='';
$p=explode('/',$_SERVER["PHP_SELF"]);
$dir_url=$_SERVER['HTTP_HOST'].'/'.$p[1];
$TOkSi = $_REQUEST['process_time'] + $_REQUEST['gwsr'] + $_REQUEST['amount'];
$my_spcheck = gwSpcheck($checkcode,$TOkSi);
$amt = 0;
$sql = "SELECT * FROM ".$config->dbprefix."virtuemart_orders WHERE virtuemart_order_id=".$order_id;
$result = mysql_query($sql);
while ($row = mysql_fetch_assoc($result)){
	$amt = intval($row['order_total']);
}
if(($my_spcheck == $_REQUEST['spcheck'] && $_REQUEST['succ']=='1') && $amt == $_REQUEST['amount']) {
	$update = "update ".$config->dbprefix."virtuemart_orders set order_status = 'C' where virtuemart_order_id = ".$order_id;
	mysql_query($update);
	$update = "update ".$config->dbprefix."virtuemart_order_items set order_status = 'C' where virtuemart_order_id = ".$order_id;
	mysql_query($update);
	echo "<script>alert('付款成功');document.location.href='http://".$_SERVER['HTTP_HOST']."';</script>";
}else {
	echo "<script>alert('付款失敗');document.location.href='http://".$_SERVER['HTTP_HOST']."';</script>";
}   
?>