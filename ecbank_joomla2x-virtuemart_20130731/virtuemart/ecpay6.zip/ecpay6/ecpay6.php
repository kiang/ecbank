﻿<?php
defined('_JEXEC') or die('Restricted access');
if (!class_exists('vmPSPlugin'))
    require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');
class plgVmPaymentEcPay6 extends vmPSPlugin {
		public $res_str = "";
    public static $_this = false;
    function __construct(& $subject, $config) {
			parent::__construct($subject, $config);
			$this->_loggable = true;
			$this->tableFields = array_keys($this->getTableSQLFields());
			$varsToPush = $this->getVarsToPush();
			$this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
    }
    public function getVmPluginCreateTableSQL() {
			return $this->createTableSQL('Payment BarCode Table');
    }
		function getTableSQLFields() {
			$SQLfields = array(
					'id' => 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT',
					'virtuemart_order_id' => 'int(1) UNSIGNED',
					'order_number' => ' char(64)',
					'virtuemart_paymentmethod_id' => 'mediumint(1) UNSIGNED',
					'payment_name' => 'varchar(5000)',
					'payment_order_total' => 'decimal(15,5) NOT NULL DEFAULT \'0.00000\'',
					'payment_currency' => 'char(3)',
					'cost_per_transaction' => 'decimal(10,2)',
					'cost_percent_total' => 'decimal(10,2)',
					'tax_id' => 'smallint(1)',
					'mer_id' => ' char(64)',
					'keys' => ' char(64)',
                                        'imer_id' => 'char(64)',
                                        'delay' => 'char(64)',                            
					'rate' => 'decimal(4,2)'
			);
			return $SQLfields;
    }
    function plgVmConfirmedOrder($cart, $order) {
			if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
					return null; 
			}
			if (!$this->selectedThisElement($method->payment_element)) {
					return false;
			}
			$lang = JFactory::getLanguage();
			$filename = 'com_virtuemart';
			$lang->load($filename, JPATH_ADMINISTRATOR);
			$vendorId = 0;
			$html = "";
			if (!class_exists('VirtueMartModelOrders'))
					require( JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php' );
			$this->getPaymentCurrency($method, true);
			$q = 'SELECT `currency_code_3` FROM `#__virtuemart_currencies` WHERE `virtuemart_currency_id`="' . $method->payment_currency . '" ';
			$db = JFactory::getDBO();
			$db->setQuery($q);
			$currency_code_3 = $db->loadResult();
			$paymentCurrency = CurrencyDisplay::getInstance($method->payment_currency);
			$order['details']['BT']->order_total = intval(round($order['details']['BT']->order_total * (1+$method->rate)));
			$totalInPaymentCurrency = round($paymentCurrency->convertCurrencyTo($method->payment_currency, $order['details']['BT']->order_total, false), 2);
			$cd = CurrencyDisplay::getInstance($cart->pricesCurrency);
			$this->_virtuemart_paymentmethod_id = $order['details']['BT']->virtuemart_paymentmethod_id;
			$dbValues['payment_name'] = $this->renderPluginName($method) . '<br />' . $method->payment_info;
			$dbValues['order_number'] = $order['details']['BT']->order_number;
			$dbValues['virtuemart_paymentmethod_id'] = $this->_virtuemart_paymentmethod_id;
			$dbValues['cost_per_transaction'] = $method->cost_per_transaction;
			$dbValues['cost_percent_total'] = $method->cost_percent_total;
			$dbValues['payment_currency'] = $currency_code_3;
			$dbValues['payment_order_total'] = $totalInPaymentCurrency;
			$dbValues['tax_id'] = $method->tax_id;
			$dbValues['mer_id'] = $method->mer_id;
			$dbValues['keys'] = $method->keys;
			$dbValues['rate'] = $method->rate;
                        $dbValues['imer_id'] = $method->imer_id;
                        $dbValues['delay'] = $method->delay;
                        $dbValues['email'] = $order['details']['BT']->email;                           
			$this->storePSPluginInternalData($dbValues);
			$html = '<table class="vmorder-done">' . "\n";
			$html .= $this->getHtmlRow('ECPAY6_PAYMENT_INFO', $dbValues['payment_name'], "vmorder-done-payinfo");
			if (!empty($payment_info)) {
					$lang = JFactory::getLanguage();
					if ($lang->hasKey($method->payment_info)) {
				$payment_info = JText::_($method->payment_info);
					} else {
				$payment_info = $method->payment_info;
					}
				$html .= $this->getHtmlRow('ECPAY6_PAYMENTINFO', $payment_info, "vmorder-done-payinfo");
			}
			$mer_id = $dbValues['mer_id'];
			$rate = $dbValues['rate'];
			$od_sob = $dbValues['order_number'];
			$amt = $dbValues['payment_order_total'];
                        $inv = $method->i_invoice;
			$str = stristr($_SERVER['PHP_SELF'],"index.php");
			$old_arry = explode ("/",$str);
			$full_arry = explode ("/",$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']);
			$cat_url = "";
			foreach($full_arry as $v){
				if($v == $old_arry[0]){
					break;	
				}
				$cat_url .= $v."/";
			}
			$res_str = '<a href="http://'.$cat_url.'plugins/vmpayment/ecpay6/show_ecpay6.php?od_sob='.$od_sob.'&amt='.$amt.'&inv='.$inv.'&vpid='.$order['details']['BT']->virtuemart_paymentmethod_id.'&order_id='.$order['details']['BT']->virtuemart_order_id.'">顯示付款畫面</a>';
			if (!class_exists('VirtueMartModelCurrency'))
					require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'currency.php');
			$currency = CurrencyDisplay::getInstance('', $order['details']['BT']->virtuemart_vendor_id);
			$html .= $this->getHtmlRow('ECPAY6_ORDER_NUMBER', $order['details']['BT']->order_number, "vmorder-done-nr");
			$html .= $this->getHtmlRow('ECPAY6_ORDER_TOTAL', $currency->priceDisplay($order['details']['BT']->order_total), "vmorder-done-amount");
			$html .= $this->getHtmlRow('ECPAY6_RATE', ($rate * 100)."%");
			$html .= $this->getHtmlRow('ECPAY6_RESPONSE', $res_str);
			$html .= '</table>' . "\n";
			$modelOrder = VmModel::getModel('orders');
			$order['order_total'] = $dbValues['payment_order_total'];
			$order['order_status'] = 'P';
			$order['customer_notified'] = 1;
			$order['comments'] = '';
			$modelOrder->updateStatusForOneOrder($order['details']['BT']->virtuemart_order_id, $order, true);
			$cart->emptyCart();
			JRequest::setVar('html', $html);
			return true;
    }
    function plgVmOnShowOrderBEPayment($virtuemart_order_id, $virtuemart_payment_id) {
			if (!$this->selectedThisByMethodId($virtuemart_payment_id)) {
					return null;
			}
			if (!($paymentTable = $this->getDataByOrderId($virtuemart_order_id) )) {
					return null;
			}
			$html = '<table class="adminlist">' . "\n";
			$html .= $this->getHtmlHeaderBE();
			$html .= $this->getHtmlRowBE('ECPAY6_PAYMENT_NAME', $paymentTable->payment_name);
			$html .= $this->getHtmlRowBE('ECPAY6_PAYMENT_TOTAL_CURRENCY', $paymentTable->payment_order_total . ' ' . $paymentTable->payment_currency);
			$html .= '</table>' . "\n";
			return $html;
				}
				function getCosts(VirtueMartCart $cart, $method, $cart_prices) {
			if (preg_match('/%$/', $method->cost_percent_total)) {
					$cost_percent_total = substr($method->cost_percent_total, 0, -1);
			} else {
					$cost_percent_total = $method->cost_percent_total;
			}
			return ($method->cost_per_transaction + ($cart_prices['salesPrice'] * $cost_percent_total * 0.01));
    }
    protected function checkConditions($cart, $method, $cart_prices) {
			$this->convert($method);
			$address = (($cart->ST == 0) ? $cart->BT : $cart->ST);
			$amount = $cart_prices['salesPrice'];
			$amount_cond = ($amount >= $method->min_amount AND $amount <= $method->max_amount
				OR
				($method->min_amount <= $amount AND ($method->max_amount == 0) ));
			if (!$amount_cond) {
					return false;
			}
			$countries = array();
			if (!empty($method->countries)) {
					if (!is_array($method->countries)) {
						$countries[0] = $method->countries;
					} else {
						$countries = $method->countries;
					}
			}
			if (!is_array($address)) {
					$address = array();
					$address['virtuemart_country_id'] = 0;
			}
			if (!isset($address['virtuemart_country_id']))
					$address['virtuemart_country_id'] = 0;
			if (count($countries) == 0 || in_array($address['virtuemart_country_id'], $countries) || count($countries) == 0) {
					return true;
			}
			return false;					
    }
    function convert($method) {
			$method->min_amount = (float) $method->min_amount;
			$method->max_amount = (float) $method->max_amount;
    }
    function plgVmOnStoreInstallPaymentPluginTable($jplugin_id) {
			return $this->onStoreInstallPluginTable($jplugin_id);
    }
    public function plgVmOnSelectCheckPayment(VirtueMartCart $cart) {
			return $this->OnSelectCheck($cart);
    }
    public function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn) {
			return $this->displayListFE($cart, $selected, $htmlIn);
    }
    public function plgVmonSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name) {
			return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
    }
    function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId) {
			if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
					return null;
			}
			if (!$this->selectedThisElement($method->payment_element)) {
					return false;
			}
			$this->getPaymentCurrency($method);
			$paymentCurrencyId = $method->payment_currency;
    }
    function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array(),   &$paymentCounter) {
			return $this->onCheckAutomaticSelected($cart, $cart_prices,   $paymentCounter);
    }
    public function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name) {
			$this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
    }
    function plgVmonShowOrderPrintPayment($order_number, $method_id) {
			return $this->onShowOrderPrint($order_number, $method_id);
    }
    function plgVmDeclarePluginParamsPayment($name, $id, &$data) {
			return $this->declarePluginParams('payment', $name, $id, $data);
    }
    function plgVmSetOnTablePluginParamsPayment($name, $id, &$table) {
			return $this->setOnTablePluginParams($name, $id, $table);
    }
}
?>