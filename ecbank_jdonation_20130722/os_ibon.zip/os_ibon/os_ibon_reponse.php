<?
    define('_JEXEC',"1");
	include ('../../../configuration.php');
	
	$siteUrl = $_SERVER['HTTP_HOST'] ;
	$base = explode("/",$_SERVER['PHP_SELF']) ;
	$jconfig = new JConfig();
	$host =  $jconfig->host;
	$user =  $jconfig->user;
	$password =  $jconfig->password;
	$db =  $jconfig->db;
	$dbprefix  =  $jconfig->dbprefix ;
    $date = date('Y-m-d H:i:s');
	
	
	$ecbank_gateway='https://ecbank.com.tw/web_service/get_outmac_valid.php';
	//組合字串
	
	$link_id = mysql_connect($host,$user,$password);
    mysql_select_db($db);
    $sqlk = " select params from  ".$dbprefix."jd_payment_plugins  where name = 'os_ibon'";
    $resultk =  mysql_query ($sqlk,$link_id);
    while ($row = mysql_fetch_assoc($resultk)){  
	    $params = $row['params'];
    }
	$enckey=substr($params,22);
	$lengtg=strlen($enckey);
	$key= substr($enckey,0,$lengtg-1);
	
	$serial = trim($_REQUEST['proc_date'].$_REQUEST['proc_time'].$_REQUEST['tsr']);
		
    $post_parm	=	'key='.$key.'&serial='.$serial.'&tac='.$_REQUEST['tac'];
			
	
    //mysql_select_db($db);
	$sqls = " select * from  ".$dbprefix."jd_donors  where id = "."'".$_REQUEST['id']."'";
    $result =  mysql_query ($sqls,$link_id);
	while ($row = mysql_fetch_assoc($result)){  
	    $amt = $row['amount'];
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$ecbank_gateway);
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$post_parm);
	$strAuth = curl_exec($ch);
	if (curl_errno($ch)) $strAuth = false;
	curl_close($ch);
	//echo $strAuth; exit;
	   
	if($strAuth == 'valid=1' && $amt==$_REQUEST['amt'] && $_REQUEST['succ']=='1') {
		
		echo "OK";

		$sql = " update ".$dbprefix."jd_donors set payment_made='1',published='1',payment_date='".$date."' , subscr_id='".$_REQUEST['tsr']."' where id = "."'".$_REQUEST['id']."'";
		//$sql = " update ".$dbprefix."jd_donors set payment_made='1',published='1',payment_date='".$date."' where id = "."'".$_REQUEST['id']."'";
			 
		mysql_query ($sql,$link_id);
		
        mysql_close($link_id);
	        
		/*$url = ("http://".$siteUrl."/".$base[1]."/index.php?option=com_jdonation&view=complete&id=".$_REQUEST['id'].'&Itemid='.$_REQUEST['Itemid']);
		
		header('Location:'. $url);*/
			
        
	} 
        
    unset($_SESSION["mer_id"]);
    unset($_SESSION["enc_key"]);		
	
	
	  
	    
       
		
		
	

?>