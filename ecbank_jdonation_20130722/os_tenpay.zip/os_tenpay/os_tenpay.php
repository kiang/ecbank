<?php
/**
 * @version		3.1
 * @package		Joomla
 * @subpackage	Joom Donation
 * @author  Tuan Pham Ngoc
 * @copyright	Copyright (C) 2010 Ossolution Team
 * @license		GNU/GPL, see LICENSE.php
 */


defined( '_JEXEC' ) or die ;
session_start();
class os_tenpay extends os_payment {
/*
	/**
	 * Paypal mode 
	 *
	 * @var boolean live mode : true, test mode : false
	 */
	var $_mode = 0 ;
	/**
	 * Paypal url
	 *
	 * @var string
	 */
	var $_url = null ;
	/**
	 * Array of params will be posted to server
	 *
	 * @var string
	 */
	var $_params = array();
	
	
	/**
	 * Array containing data posted from paypal to our server
	 *
	 * @var array
	 */
	var $_data = array();
	/**
	 * Constructor functions, init some parameter
	 *
	 * @param object $config
	 */
	function os_tenpay($params) {
	    
		parent::setName('os_tenpay');
		parent::os_payment();						
		parent::setCreditCard(false);		
    	parent::setCardType(false);
    	parent::setCardCvv(false);
    	parent::setCardHolderName(false);
		$this->ipn_log = true ;
		$this->ipn_log_file = JPATH_COMPONENT.'/ipn_logs.txt';
		$this->_url = 'https://ecbank.com.tw/gateway.php';
		$this->setParam('business', $params->get('paypal_id'));	
		$this->setParam('rm', 2);
		$this->setParam('cmd', '_xclick');		
		$this->setParam('no_shipping', 1);
		$this->setParam('no_note', 1);
		$this->setParam('lc', 'US');		
		$this->setParam('currency_code', $params->get('paypal_currency', 'USD'));
		$this->setParam('client', $params->get('allpay'));
		$this->setParam('mer_id', $params->get('merid'));
		$this->setParam('enc_key', $params->get('enc_key'));
		$_SESSION["mer_id"] = $params->get('merid') ;
		$_SESSION["enc_key"] =  $params->get('enc_key') ;
		
		
		
	}
	
	
	/**
	 * Set param value
	 *
	 * @param string $name
	 * @param string $val
	 */
	function setParam($name, $val) {
		$this->_params[$name] = $val;
	}
	/**
	 * Setup payment parameter
	 *
	 * @param array $params
	 */
	
	function setParams($params) {
		foreach ($params as $key => $value) {
			$this->_params[$key] = $value ;
		   
		}
		
		
	}
	/**
	 * Check to see whether this payment gateway support recurring payment
	 *
	 */	
	function getEnableRecurring() {
		return 0 ;
	}
	/**
	 * Process Payment
	 *
	 * @param object $row
	 * @param array $params
	 */
	function processPayment($row, $data) {
		$Itemid = JRequest::getInt('Itemid');
		$siteUrl = JURI::base() ;									
		if (isset($data['paypal_id'])) {
			$this->setParam('business', $data['paypal_id']);
		}
		if (isset($data['currency_code']) && $data['currency_code']!= '') {
			$this->setParam('currency_code', $data['currency_code']);
		}
		$this->setParam('item_name', $data['item_name']); 
		$this->setParam('amt', intval($data['gateway_amount']));
		$this->setParam('custom', $row->id);													
		//$this->setParam('roturl', $siteUrl.'index.php?option=com_jdonation&view=complete&id='.$row->id.'&Itemid='.$Itemid);
		//$return_url = "http://".$_SERVER['HTTP_HOST'].str_replace(basename(__FILE__),"os_allpay_response.php",$_SERVER['PHP_SELF']);
        //$this->setParam('roturl', $siteUrl.'components/com_jdonation/payments/os_tenpay_reponse.php?id='.$row->id.'&Itemid='.$Itemid);
        $this->setParam('return_url', $siteUrl.'components/com_jdonation/payments/os_tenpay_reponse.php?id='.$row->id.'&Itemid='.$Itemid);
        $this->setParam('ok_url', $siteUrl.'components/com_jdonation/payments/os_tenpay_reponse.php?id='.$row->id.'&Itemid='.$Itemid);		
		$this->setParam('cancel_return', $siteUrl.'index.php?option=com_jdonation&task=cancel&id='.$row->id.'&Itemid='.$Itemid);
		$this->setParam('notify_url', $siteUrl.'index.php?option=com_jdonation&task=payment_confirm&payment_method=os_tenpay');		
		$this->setParam('address1', $row->address);		
		$this->setParam('address2', $row->address2);		
		$this->setParam('city', $row->city);		
		$this->setParam('country', $row->country);		
		$this->setParam('first_name', $row->first_name);
		$this->setParam('last_name', $row->last_name);
		$this->setParam('state', $row->state);
		$this->setParam('zip', $row->zip);
		$this->setParam('mer_id', $_SESSION["mer_id"]);
		$this->setParam('enc_key', $_SESSION["enc_key"]);
		$this->setParam('payment_type', 'tenpay');
		$this->setParam('od_sob', $row->id);
		
		$this->submitPost();				
	}
	/**
	 * Submit post to paypal server
	 *
	 */	
	function submitPost() {
		$redirectMessage = JoomDonationHelper::getConfigValue('paypal_redirect_message') ;			
		if (strlen(trim($redirectMessage))) {
		?>
			<p><?php echo $redirectMessage; ?></p>
		<?php	
		} else {
		?>
			<div class="contentheading"><?php echo  'Please wait for reducing to payment gateway .'; ?></div>	
		<?php
		}
		?>		
		<form method="post" action="<?php echo $this->_url; ?>" name="os_form" id="os_form">
			<?php
				foreach ($this->_params as $key=>$val) {
				   
					echo '<input type="hidden" name="'.$key.'" value="'.$val.'" />';
					echo "\n";	
				}
			?>
			<script type="text/javascript">
				function redirect() {
					document.os_form.submit();
				}
				setTimeout('redirect()',5000);
			</script>
		</form>
	<?php	
	}
	
	/*function submitPostr() {
		$redirectMessage = JoomDonationHelper::getConfigValue('paypal_redirect_message') ;			
		if (strlen(trim($redirectMessage))) {
		?>
			<p><?php echo $redirectMessage; ?></p>
		<?php	
		} else {
		?>
			<div class="contentheading"><?php echo  'Please wait for reducing to payment gateway .'; ?></div>	
		<?php
		}
		?>		
		<form method="post" action="<?php echo "https://ecbank.com.tw/gateway_batch.php"; ?>" name="os_form" id="os_form">
			<?php
				foreach ($this->_params as $key=>$val) {
					echo '<input type="hidden" name="'.$key.'" value="'.$val.'" />';
					echo "\n";	
				}
			?>
			<script type="text/javascript">
				function redirect() {
					document.os_form.submit();
				}
				setTimeout('redirect()',5000);
			</script>
		</form>
	<?php	
	}*/
	/**
	 * Process recurring payment
	 *
	 * @param object $row
	 * @param object $data
	 */	
	/*function processRecurringPayment($row, $data){
		$Itemid = JRequest::getInt('Itemid');		
		$siteUrl = JURI::base() ;		
		$this->setParam('item_name', $data['item_name']);				
		if (isset($data['currency_code']) && $data['currency_code']!= '') 
			$this->setParam('currency_code', $data['currency_code']);
	    if (isset($data['paypal_id'])) {
			$this->setParam('business', $data['paypal_id']);
		}								
		$this->setParam('custom', $row->id);
		$this->setParam('roturl', $siteUrl.'components/com_jdonation/payments/os_allpay_reponse.php?id='.$row->id.'&Itemid='.$Itemid);
        $this->setParam('return_url', $siteUrl.'components/com_jdonation/payments/os_allpay_reponse.php?id='.$row->id.'&Itemid='.$Itemid);
		$this->setParam('bk_url', $siteUrl.'components/com_jdonation/payments/os_allpay_reponse.php?id='.$row->id.'&Itemid='.$Itemid);
		$this->setParam('cancel_return', $siteUrl.'index.php?option=com_jdonation&task=cancel&id='.$row->id.'&Itemid='.$Itemid);
		$this->setParam('notify_url', $siteUrl.'index.php?option=com_jdonation&task=recurring_donation_confirm&payment_method=os_allpay');		
		$this->setParam('cmd', '_xclick-subscriptions');
		$this->setParam('src', 1);		
		$this->setParam('sra', 1);
		$this->setParam('a3', $data['gateway_amount']);
		$this->setParam('address1', $row->address);			
		$this->setParam('address2', $row->address2);		
		$this->setParam('city', $row->city);		
		$this->setParam('country', $row->country);				
		$this->setParam('first_name', $row->first_name);
		$this->setParam('last_name', $row->last_name);
		$this->setParam('state', $row->state);		
		$this->setParam('zip', $row->zip);						 															
		switch ($row->r_frequency) {
			case 'd':
				$p3 = 1 ;
				$t3 = 'D';
				break ;
			case 'w' :
				$p3 = 1 ;
				$t3 = 'week' ;
				break ;
			case 'm' :
				$p3 = 1 ;
				$t3 = 'month' ;
				break ;
			case 'q' :
				$p3 = 3 ;
				$t3 = 'M' ;
				break ;
			case 's' :
				$p3 = 6 ;
				$t3 = 'M' ;
				break ;
			case 'a' :
				$p3 = 1 ;
				$t3 = 'Y';
				break ;					
		}*/
		/*switch ($row->r_frequency) {
			
			case 'w' :
				$p3 = 1 ;
				$t3 = 'week' ;
				break ;
			case 'm' :
				$p3 = 1 ;
				$t3 = 'month' ;
				break ;
			case 's' :
				$p3 = 1 ;
				$t3 = 'year' ;
				break ;
				
		}*/
		/*$this->setParam('p3', $p3);
		$this->setParam('t3', $t3);
		$this->setParam('lc', 'US');							
		if ($row->r_times > 1) {
			$this->setParam('srt', $row->r_times);			
		}
		
        $ecbank_gateway='https://ecbank.com.tw/web_service/hand_shake.php';
		// 組合字串
		
		//echo "<hr>".$checkcode."<hr>";

		$post_parm	=	'mer_id='.$_SESSION["mer_id"].'&enc_key='.$_SESSION["enc_key"];
		
		//echo "<hr>".$post_parm; 
	    
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$ecbank_gateway);
		curl_setopt($ch, CURLOPT_VERBOSE, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$post_parm);
		$strAuth = curl_exec($ch);
		if (curl_errno($ch)) $strAuth = false;
		curl_close($ch);
    	
        $this->setParam('action', '1');
		$this->setParam('amt', intval($data['gateway_amount']));
		$this->setParam('od_sob', $row->id);
		$this->setParam('key', $strAuth);
		$this->setParam('stage', $row->r_times);
		if(($row->r_frequency) !='w' && ($row->r_frequency) !='m'){
		
		    $this->setParam('stage_cycle','year');
		}else{
		    $this->setParam('stage_cycle', $t3);
		}
		$this->submitPostr();
        //unset($_SESSION["mer_id"]);
       // unset($_SESSION["enc_key"]);		
	}*/	
	/**
	 * Validate the post data from paypal to our server
	 *
	 * @return string
	 */
	/*function _validate($process_date,$process_time,$gwsr,$rech_key,$amount) {
		/*$errNum="";
	   	$errStr="";
	    $urlParsed = parse_url($this->_url);
	    $host = $urlParsed['host'];
	    $path = $urlParsed['path'];        
	    $postString = ''; 
	    $response = '';   
	    foreach ($_POST as $key=>$value) { 
	       $this->_data[$key] = $value;
	       $postString .= $key.'='.urlencode($value).'&'; 
	    }
	    $postString .='cmd=_notify-validate';
	    $fp = fsockopen($host , '80', $errNum, $errStr, 30); 
	      if(!$fp) {	                
	         return false;
	      } else {	      		
	         fputs($fp, "POST $path HTTP/1.1\r\n"); 
	         fputs($fp, "Host: $host\r\n"); 
	         fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n"); 
	         fputs($fp, "Content-length: ".strlen($postString)."\r\n"); 
	         fputs($fp, "Connection: close\r\n\r\n"); 
	         fputs($fp, $postString . "\r\n\r\n"); 
	         while(!feof($fp)) { 
	            $response .= fgets($fp, 1024); 
	         } 
	         fclose($fp);
	      }	      	
	     $this->ipn_response = $response ;       
	     $this->log_ipn_results(true); 
	    if ($this->_mode) {
	         if (eregi("VERIFIED", $response)) 	         
    	       	 return true;       
    	     else 	           
    	         return false;
	     } else {
	        //Always return true for test mode 
	     	return true ;       
	     }*/	
        /*$ecbank_gateway='https://ecpay.com.tw/g_recheck.php';
		// 組合字串
		$serial = trim($process_date.$process_time.$gwsr);
		//echo "<hr>".$checkcode."<hr>";

		$post_parm	=	'key='.$rech_key.'&serial='.$serial.'&amt='.$amount;
		
		//echo "<hr>".$post_parm; 


		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$ecbank_gateway);
		curl_setopt($ch, CURLOPT_VERBOSE, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$post_parm);
		$strAuth = curl_exec($ch);
		if (curl_errno($ch)) $strAuth = false;
		curl_close($ch);
	  //echo $strAuth; exit;
	
		if($strAuth == 'valid=1') {
        	return 'true';
    	}  else {
    		return 'fail';
    	} 
        
	}
	/**
	 * Log IPN result
	 *
	 * @param string $success
	 */
	/*function log_ipn_results($success) {
      if (!$this->ipn_log) return;
      $text = '['.date('m/d/Y g:i A').'] - '; 
      if ($success) $text .= "SUCCESS!\n";
      	else $text .= 'FAIL: '.$this->last_error."\n"; 
      $text .= "IPN POST Vars from Paypal:\n";
      foreach ($this->_data as $key=>$value) {
         $text .= "$key=$value, ";
      }
      $text .= "\nIPN Response from Paypal Server:\n ".$this->ipn_response;
      $fp=fopen($this->ipn_log_file,'a');
      fwrite($fp, $text . "\n\n"); 
      fclose($fp);  // close file
   }*/      
	/**
	 * Process payment 
	 *
	 */
	/*function verifyPayment() {
		/*$ret = $this->_validate();
       	$incom_check=$this->_validate($_POST['process_date'],$_POST['process_time'],$_POST['gwsr'],$_POST['rech_key'],$_POST['amount']);
		if ($_POST['succ'] == '1'  && $incom_check=='true') {
			$config = JoomDonationHelper::getConfig() ;
			$id = $this->_data['custom'];						
   			$transactionId = $this->_data['txn_id'];
   			$amount = $this->_data['mc_gross'];
   			if ($amount < 0)
   				return false ;
   			$row =  JTable::getInstance('jdonation', 'Table');
   			$row->load($id);
   			if (!$row->id)
   				return false ;
   			$published = $row->published ;
   			$row->transaction_id = $transactionId ;
   			$row->payment_date =  date('Y-m-d H:i:s');
   			$row->published = true;
   			$row->store();   
   			if (!$published) {
   				JoomDonationHelper::sendEmails($row, $config);
   				JPluginHelper::importPlugin( 'jdonation' );
   				$dispatcher = JDispatcher::getInstance();
   				$dispatcher->trigger( 'onAfterPaymentSuccess', array($row));
   			}		   			   			
   			return true;	
		} else {
			return false;
		}
        //return false;
	}*/
	/**
	 * Verify recrrung payment
	 *
	 */
	 /*
	function verifyRecurringPayment() {
		$ret = $this->_validate();				
		if ($ret) {
			$config = JoomDonationHelper::getConfig() ;
			$id = $this->_data['custom'];						
   			$transactionId = $this->_data['txn_id'];
   			$amount = $this->_data['mc_gross'];
   			$txnType = $this->_data['txn_type'] ;
   			$subscrId = $this->_data['subscr_id'] ;   			 		
   			if ($amount < 0)
   				return false ;
   			$row =  JTable::getInstance('jdonation', 'Table');	
   			switch ($txnType) {
   				case 'subscr_signup' :
   					$row->load($id);
   					if (!$row->id)
   						return false ;	
   					$published = $row->published ;
		   			$row->transaction_id = $transactionId ;
		   			$row->payment_date =  date('Y-m-d H:i:s');
		   			$row->published = true;
		   			$row->subscr_id = $subscrId ;
		   			$row->store();		
		   			if (!$published)
		   				JoomDonationHelper::sendEmails($row, $config);   			
		   			break ;			
   				case 'subscr_payment' :
   					$row->load($id);
   					if (!$row->id)
   						return false ;	
   					$row->payment_made = $row->payment_made + 1 ;
   					if ($row->payment_made > 1) {
   						$row->amount = $row->amount + $row->recurring_amount ;
   					}
   					$row->store();
   					JRequest::setVar('receive_amount', $amount) ;
   					if ($row->payment_made > 1) {   						
   						JoomDonationHelper::sendRecurringEmail($row, $config);
   					}	   					    				
   					break ;   				 
   			}	   				   			   			   			
   			return true;	
		} else {
			return false;
		}		
	}*/

    
	
	   
	
	    
}